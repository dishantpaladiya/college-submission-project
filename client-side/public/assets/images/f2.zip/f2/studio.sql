-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2020 at 05:26 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studio`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_mem`
--

CREATE TABLE `add_mem` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(1) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `phno` bigint(12) NOT NULL,
  `address` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_mem`
--

INSERT INTO `add_mem` (`id`, `fname`, `mname`, `lname`, `phno`, `address`, `status`, `dob`, `gender`, `image`) VALUES
(6, 'Janvi', 'V', 'Dhameliya', 2147483647, '52, sarita soc., ambatalavdi, katargam, surat -395004', 'single', '1995-02-02', 'Female', '20200329181125.jpg'),
(9, 'Rutvik', 'd', 'dholakiya', 7284866164, '12, ABC nagar soc.,', 'single', '2000-05-17', 'Male', '20200329183239.jpg'),
(10, 'Nidhi', 'B', 'Patel', 9924597253, '12, sarita soc., ambatalavdi, katargam, surat -395004', 'Single', '1998-12-12', 'Female', '20200329201403.jpg'),
(15, 'mahi', 'b', 'patel', 7685678908, '12, haridham soc.,katargam, surat', 'single', '2000-02-22', 'Female', '20200330133508.jpg'),
(17, 'Parth', 'G', 'patel', 8876567897, '12, haridham soc.,katargam, surat', 'Single', '2000-02-22', 'Male', '20200330134228.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cdate`
--

CREATE TABLE `cdate` (
  `id` int(10) UNSIGNED NOT NULL,
  `day` varchar(10) NOT NULL,
  `month` varchar(10) NOT NULL,
  `year` varchar(10) NOT NULL,
  `place` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cdate`
--

INSERT INTO `cdate` (`id`, `day`, `month`, `year`, `place`) VALUES
(3, '1', '3', '2020', ''),
(4, '1', '2', '2020', ''),
(7, '12', '2', '2020', ''),
(8, '4', '2', '2020', '');

-- --------------------------------------------------------

--
-- Table structure for table `cimages`
--

CREATE TABLE `cimages` (
  `imgid` int(11) NOT NULL,
  `src` text NOT NULL,
  `cid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cimages`
--

INSERT INTO `cimages` (`imgid`, `src`, `cid`) VALUES
(2, '1193_1.JPEG', 5),
(12, '7451_download.jpg', 0),
(18, '9163_port12.jpg', 6),
(19, '9832_port10.jpg', 6),
(20, '1113_port2.jpg', 7),
(21, '3869_port15.jpg', 7),
(22, '4700_port14.jpg', 9),
(23, '5162_port11.jpg', 9),
(24, '3970_port11.jpg', 0),
(25, '9313_port4.jpg', 18),
(26, '5558_port3.jpg', 18),
(27, '5958_port9.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `clogin`
--

CREATE TABLE `clogin` (
  `cid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clogin`
--

INSERT INTO `clogin` (`cid`, `username`, `pass`, `id`) VALUES
(5, 'rutvik', '1', 1),
(6, 'dhvani', '12', 2),
(7, 'Arjun', '123', 3),
(9, 'dhruvi', '1234', 4),
(18, 'akash', '1234', 5),
(19, 'urvish', '1234', 6),
(20, 'parth', '1234', 7);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `cid` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `subject` varchar(20) NOT NULL,
  `message` varchar(20) NOT NULL,
  `approval` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `name`, `email`, `subject`, `message`, `approval`) VALUES
(10, 'Piyush Shanghani', 'piyushpatel15@gmail.com', 'About Photo upload.', 'piyush', 'Not Allowed'),
(11, 'Sanjay Vastarpara', 'sanjay4405@gmail.com', 'About Photo upload.', 'Sanjay', 'Not Allowed'),
(12, 'Aastha Aadhav', 'sasli@gmail.com', 'About Photo upload.', 'sasli', 'Allowed');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) UNSIGNED NOT NULL,
  `usname` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `usname`, `pass`) VALUES
(4, 'rutvik', 'rut.s');

-- --------------------------------------------------------

--
-- Table structure for table `newsletterlog`
--

CREATE TABLE `newsletterlog` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(52) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `news` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `odetail`
--

CREATE TABLE `odetail` (
  `id` int(10) NOT NULL,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text DEFAULT NULL,
  `LName` text DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `pcode` int(10) DEFAULT NULL,
  `Phone` text DEFAULT NULL,
  `stype` varchar(20) DEFAULT NULL,
  `fdate` date DEFAULT NULL,
  `to` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `loca` varchar(50) DEFAULT NULL,
  `msg` varchar(150) DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL,
  `tamount` int(11) NOT NULL,
  `pamount` int(11) NOT NULL,
  `damount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `odetail`
--

INSERT INTO `odetail` (`id`, `Title`, `FName`, `LName`, `Email`, `address`, `Country`, `city`, `state`, `pcode`, `Phone`, `stype`, `fdate`, `to`, `time`, `loca`, `msg`, `stat`, `nodays`, `tamount`, `pamount`, `damount`) VALUES
(1, 'Mr.', 'Rutvik', 'Dholakya', 'rutvik4242@gmail.com', '42, shankar nagar soc.,', 'India', 'surat', 'Gujarat', 395004, '07284866164', 'Wedding', '2020-02-01', '2020-02-03', '11:11:00', 'surat', 'HELLO', 'Confirm', -2, 0, 0, 0),
(2, 'Miss.', 'dhvani', 'patel', 'dpatel@gmail.com', '42, abc nagar,', 'India', 'surat', 'gujrat', 395004, '09999990090', 'Wedding', '2020-03-02', '2020-03-04', '14:22:00', 'surat', 'WORLD', 'Confirm', -2, 0, 0, 0),
(3, 'Prof.', 'Arjun', 'shinghaniya', 'ashin@gmail.com', '22,abc nagar', 'India', 'surat', 'gujarat', 395004, '09977565678', 'New Born', '2020-05-05', '2020-05-07', '14:22:00', 'surat', 'LUCKY', 'Confirm', -2, 0, 0, 0),
(4, 'Miss.', 'dhruvi', 'jasoliya', 'djasoliya@gmail.com', '101, shari nagar soc.,', 'India', 'surat', 'gujarat', 395004, '9998765432', 'New Born', '2020-02-12', '2020-02-13', '15:33:00', 'Hirabag', 'NGO', 'Confirm', -1, 2000, 200, 0),
(5, 'Mr.', 'akash', 'maniya', 'amaniya@gmail.com', '51, abc soc.,', 'India', 'surat', 'gujarat', 888090, '9192738495', 'Children', '2020-02-22', '2020-02-26', '14:22:00', 'surat', 'Home', 'Confirm', 4, 5000, 5000, 0),
(6, 'Mr.', 'urvish', 'chaludiya', 'uc@gmail.com', '32,abc nagar soc.', 'India', 'Surat', 'Surat', 395004, '7778897172', 'Wedding', '2020-02-22', '2020-02-22', '11:11:00', 'KAtargam', '', 'Confirm', 0, 0, 0, 0),
(7, 'Mr.', 'parth', 'Bhikadiya', 'PB@gmail.com', '50, Patel Park Soc., Lalita Chokdi, Katargam, Surat', 'India', 'surat', 'Gujarat', 395004, '7567501061', 'Wedding', '2020-04-12', '2020-04-14', '11:11:00', 'Katargam', '', 'Confirm', 2, 90000, 20000, 0),
(8, 'Miss.', 'vidhi', 'patel', 'vdpatel@gmail.com', '52, sarita soc., ambatalavdi, katargam, surat -395004', 'India', 'surat', 'gujarat', 395004, '7685678908', 'Wedding', '2020-05-17', '2020-05-19', '19:00:00', 'Gurukul School', '', 'Not Confirm', 2, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `pid` int(11) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`pid`, `detail`, `amount`) VALUES
(1, 'Photography package 1 day', '10,000 - 25,000'),
(2, 'Photo + video package 1 day', '35,000 - 55,000'),
(3, 'Pre wedding photography', '15,000 - 35,000'),
(4, 'Photography package 2 days', '20,000 - 45,000'),
(5, 'Photo + video package 2 days', '60,000 - 1,00,000'),
(6, 'Photography package 3 days', '30,000 - 55,000'),
(7, 'Photo + video package 3 days', '1,00,000 - 1,50,000'),
(8, 'Album additionally', '10,000 - 15,000'),
(9, 'Traditional photography, per day', '10,000 - 15,000'),
(10, 'Candid photography, per day', '15,000 - 25,000');

-- --------------------------------------------------------

--
-- Table structure for table `package_img`
--

CREATE TABLE `package_img` (
  `id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package_img`
--

INSERT INTO `package_img` (`id`, `image`) VALUES
(9, '20200330085540.jpg'),
(10, '20200330085546.jpg'),
(12, '20200330085556.jpg'),
(14, '20200330085614.jpg'),
(15, '20200330085622.jpg'),
(17, '20200330085639.jpg'),
(18, '20200330085648.jpg'),
(22, '20200330092000.jpg'),
(23, '20200330092009.jpg'),
(24, '20200330092018.jpg'),
(25, '20200330092028.jpg'),
(26, '20200330092038.jpg'),
(27, '20200330092431.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `requirement`
--

CREATE TABLE `requirement` (
  `rid` int(11) NOT NULL,
  `det1` char(50) DEFAULT NULL,
  `det2` char(50) DEFAULT NULL,
  `det3` char(50) DEFAULT NULL,
  `det4` char(50) DEFAULT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requirement`
--

INSERT INTO `requirement` (`rid`, `det1`, `det2`, `det3`, `det4`, `id`) VALUES
(13, '4 videographer', '2 dron', '5 photographer', '4 album', 1),
(14, '1 dron', '2 dron', '3 video', '4 album', 2),
(17, '4 videographer', '2 dron', '3 videographer', '4 album', 8);

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `month`, `year`) VALUES
(23, 1, 2020),
(24, 2, 2020);

-- --------------------------------------------------------

--
-- Table structure for table `slogin`
--

CREATE TABLE `slogin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slogin`
--

INSERT INTO `slogin` (`id`, `username`, `pass`) VALUES
(2, 'vishal', 'vishal'),
(3, 'akash', 'akash'),
(4, 'hiren', 'hiren');

-- --------------------------------------------------------

--
-- Table structure for table `view_salary`
--

CREATE TABLE `view_salary` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `sername` varchar(30) NOT NULL,
  `salary` bigint(20) NOT NULL,
  `sid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `view_salary`
--

INSERT INTO `view_salary` (`id`, `name`, `sername`, `salary`, `sid`) VALUES
(29, 'vishal', 'shingala', 50000, 23);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_mem`
--
ALTER TABLE `add_mem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cdate`
--
ALTER TABLE `cdate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cimages`
--
ALTER TABLE `cimages`
  ADD PRIMARY KEY (`imgid`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `clogin`
--
ALTER TABLE `clogin`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletterlog`
--
ALTER TABLE `newsletterlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `odetail`
--
ALTER TABLE `odetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `package_img`
--
ALTER TABLE `package_img`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requirement`
--
ALTER TABLE `requirement`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slogin`
--
ALTER TABLE `slogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `view_salary`
--
ALTER TABLE `view_salary`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_mem`
--
ALTER TABLE `add_mem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `cdate`
--
ALTER TABLE `cdate`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cimages`
--
ALTER TABLE `cimages`
  MODIFY `imgid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `clogin`
--
ALTER TABLE `clogin`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `cid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `newsletterlog`
--
ALTER TABLE `newsletterlog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `odetail`
--
ALTER TABLE `odetail`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `package_img`
--
ALTER TABLE `package_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `requirement`
--
ALTER TABLE `requirement`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `slogin`
--
ALTER TABLE `slogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `view_salary`
--
ALTER TABLE `view_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clogin`
--
ALTER TABLE `clogin`
  ADD CONSTRAINT `clogin_ibfk_1` FOREIGN KEY (`id`) REFERENCES `odetail` (`id`);

--
-- Constraints for table `requirement`
--
ALTER TABLE `requirement`
  ADD CONSTRAINT `requirement_ibfk_1` FOREIGN KEY (`id`) REFERENCES `odetail` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
