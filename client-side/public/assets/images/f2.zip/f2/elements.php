<?php
include('db.php');
include('head.php');
?>

<body>
   
    <?php include('header.php'); ?>

    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/elements.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-8">
                        <div class=""></div>
                        <h2>Elements</h2>
                        <p>All packages require a non-refundable £400 retainer fee to be paid at the time of booking. The remaining balance is due one month before your wedding.</p>
                        <!-- <a href="contact.php" class="btn sonar-btn white-btn">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Hero Area End ***** -->
    <section class="elements-area section-padding-100-0">
        <div class="container">   

            <div class="plans-section" >
                <div class="container">
                <div class="col-12">
                    <div class="contact-form text-center">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="100ms">

                        <h4>PACKAGES</h4>
                <br>
             
    <?php
						include ('db.php');
						$sql = "select * from package";
						$re = mysqli_query($con,$sql);
						$c =0;
						while($row=mysqli_fetch_array($re) );
						{
								$detail = isset($row['detail']);
								$amount = isset($row['amount']);
                                $pid = isset($row['pid']);
                        };
								
	?>


                        <div class="panel-body">
                        <div class="single-services-area wow fadeInUp" data-wow-delay="100ms">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Detail</th>
                                            <th>Amount</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>


                                    <?php
									$tsql = "select * from package";
									$tre = mysqli_query($con,$tsql);
									while($trow=mysqli_fetch_array($tre) )
										
										{
											echo"<tr>
												<th>".$trow['detail']."</th>
                                                <th>".$trow['amount']."</th>
												</tr>";
										}	
									
									
									?>

                                    </tbody>
                                </table>
								
                            </div>
                        </div>
                    </div>

                                  
                               
                 

    
  
                

    
        
            <div class="row">
                <!-- Single Services Area -->
                <div class="col-12">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="300ms">
                        <img style="width: 3rem" src="img/core-img/camera.png" alt="">
                        <h4>Wedding Photograpy</h4>
                        
                        <h5>INCLUDES:</h5>
                        <br>
                        
                        
                        <p><span>&rarr; &nbsp;</span>A pre-wedding consultation and planning session. (In person or via Skype).</p>
                        <p><span>&rarr; &nbsp;</span>Photography coverage of morning preparations, the ceremony and the reception until you sit for dinner.</p>
                        <p><span>&rarr; &nbsp;</span>400-600 fine-art photographs presented as high-resolution digital jpegs.</p>
                        <p><span>&rarr; &nbsp;</span>Your wedding images are professionally edited to the highest standard. </p>
                        <p><span>&rarr; &nbsp;</span>Two wedding photographers to cover your day. </p>
                        <p><span>&rarr; &nbsp;</span>An online password protected gallery for sharing your photography with friends & family. </p>
                        <p><span>&rarr; &nbsp;</span>Copyright of your wedding photos is included.</p>
                        <p><span>&rarr; &nbsp;</span>(Please note, depending on your wedding location there may be an additional travel & accommodation fee.) </p>
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="600ms">
                        <img  style="width: 3rem" src="img/core-img/vector.png" alt="">
                        <h4>Album package</h4>
                        <h5>INCLUDES:</h5>
                        <br>
                        
                        
                        <p><span>&rarr; &nbsp;</span>All of the above and ... </p>
                        <p><span>&rarr; &nbsp;</span>A Fine-Art 30 page 10 x 10 inch Album printed on giclée paper with archival ink designed by Weddings by King Photography.</p>
                        <p><span>&rarr; &nbsp;</span>Copyright of your wedding photos is included.</p>
                        <p><span>&rarr; &nbsp;</span>(Please note, depending on your wedding location there may be an additional travel & accommodation fee.) </p>
                                
                

                    <br>
                    <br>
                    <br>
                    <div class="single-services-area wow fadeInUp" data-wow-delay="700ms">

                        <h4>WEDDING PHOTOGRAPHY PERKS</h4>
                </div>
                </div>
                </div>
                <br>
                <br>

                <div class="col-12 col-md-6 col-lg-6">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="300ms">

                        <h5> extra photography coverage</h5>
                        <br>
                        <p>One of our most popular additional options. Extend your photography coverage to include your speeches, dinner and first dance. Unless otherwise specified and arranged, this coverage ends at 21:45.</p>
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="600ms">
                        <h5> wedding webpage</h5>
                        <br>
                        <p>We create your own personal wedding webpage. It is online from a few months before your wedding until 5 months afterwards. We can include information about your wedding locations, maps, accommodation and more.</p>
                    </div>
                </div>
                <!-- Single Services Area -->
                
                <div class="col-12">
                    <div class="contact-form text-center">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="900ms">
                        
                        <h5> engagement shoot/couple session</h5>
                        <br>
                        <p>Relaxed photography of two people in love. We venture outdoors and wander someplace with beautiful natural surroundings. This is a completely informal and leisurely photography shoot. If you are one of our wedding couples  these shoots are a fabulous way to become accustomed to our style and of course being in front of the camera. Wedding clients also regularly use photographs from these pre-wedding shoots in their wedding, as signing boards or printed into guest signing books.</p>
                        <br>
                        <p>These couple shoots are not limited to wedding clients, they are also really lovely anniversary, valentines day and birthday gifts. </p>

                        <br>
                        <br>
                        <br>
                        <div class="single-services-area wow fadeInUp" data-wow-delay="1100ms">
                        
                        <h5> wedding adventure shoot</h5>
                        <br>
                        <p>Relaxed photography of two people in love. We venture outdoors and wander someplace with beautiful natural surroundings. This is a completely informal and leisurely photography shoot. If you are one of our wedding couples these shoots are a fabulous way to become accustomed to our style and of course being in front of the camera. Wedding clients also regularly use photographs from these pre-wedding shoots in their wedding, as signing boards or printed into guest signing books.</p>
                        <br>
                        <p>These couple shoots are not limited to wedding clients, they are also really lovely anniversary, valentines day and birthday gifts. </p>

                        <br>
                        <br>
                        <br>
                        <div class="single-services-area wow fadeInUp" data-wow-delay="1400ms">
                        
                        <h5> wedding albums</h5>
                        <br>
                        <p>We offer three gorgeous wedding album styles. Please have a look at them in detail on our wedding album page.</p>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>


      
    <section class="elements-area section-padding-100-0">
        <div class="container">   

           

            <!-- ***** Progress Bars & Accordions ***** -->
            <div class="row">
                <div class="col-12">
                    <div class="elements-title">
                        <h2>Progress Bars &amp; Accordions</h2>
                    </div>

                    <div class="row">
                        <div class="col-12 col-md-6">
                            <!-- Progress Bar Content Area -->
                            <div class="services-progress-bar mb-100">
                                <!-- Single Progress Bar -->
                                <div class="single_progress_bar">
                                    <div id="bar1" class="barfiller">
                                        <div class="tipWrap">
                                            <span class="tip"></span>
                                        </div>
                                        <span class="fill" data-percentage="80"></span>
                                    </div>
                                    <p>Pacience</p>
                                </div>
                                <!-- Single Progress Bar -->
                                <div class="single_progress_bar">
                                    <div id="bar2" class="barfiller">
                                        <div class="tipWrap">
                                            <span class="tip"></span>
                                        </div>
                                        <span class="fill" data-percentage="90"></span>
                                    </div>
                                    <p>Creativity</p>
                                </div>
                                <!-- Single Progress Bar -->
                                <div class="single_progress_bar">
                                    <div id="bar3" class="barfiller">
                                        <div class="tipWrap">
                                            <span class="tip"></span>
                                        </div>
                                        <span class="fill" data-percentage="100"></span>
                                    </div>
                                    <p>Commited</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-6">
                            <div class="accordions mb-100" id="accordion" role="tablist" aria-multiselectable="true">
                                <!-- single accordian area -->
                                <div class="panel single-accordion">
                                    <h6><a role="button" class="" aria-expanded="true" aria-controls="collapseOne" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Best Quality
                                    <span class="accor-open"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                    <span class="accor-close"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                    </a></h6>
                                    <div id="collapseOne" class="accordion-content collapse show">
                                        <p>We are popular for photo album and video output best quality in India. We are provide best quality in photo, video and material.</p>
                                    </div>
                                </div>
                                <!-- single accordian area -->
                                <div class="panel single-accordion">
                                    <h6>
                                        <a role="button" class="collapsed" aria-expanded="true" aria-controls="collapseTwo" data-parent="#accordion" data-toggle="collapse" href="#collapseTwo">Best Place
                                        <span class="accor-open"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                        <span class="accor-close"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                        </a>
                                    </h6>
                                    <div id="collapseTwo" class="accordion-content collapse">
                                        <p>We are try to best result to anywhere and any places. thinking to do best in any condition. and try to use maximum place for photo and video shoot.</p>
                                    </div>
                                </div>
                                <!-- single accordian area -->
                                <div class="panel single-accordion">
                                    <h6>
                                        <a role="button" aria-expanded="true" aria-controls="collapseThree" class="collapsed" data-parent="#accordion" data-toggle="collapse" href="#collapseThree">Unique Idea
                                        <span class="accor-open"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                        <span class="accor-close"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                    </a>
                                    </h6>
                                    <div id="collapseThree" class="accordion-content collapse">
                                        <p>We are use many type of crops for best moment, and provide all facility. We are trying to click new poses and new ideas.</p>
                                    </div>
                                </div>
                                
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ***** Loaders ***** -->
            <div class="row">
                <div class="col-12">
                    <div class="elements-title">
                        <h2>Loaders</h2>
                    </div>

                    <div class="our-skills-area text-center">
                        <div class="row">
                            <div class="col-12 col-sm-6 col-md-3">
                                <div class="single-pie-bar mb-100" data-percent="90">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Landsacpes</p>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <div class="single-pie-bar mb-100" data-percent="65">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Portraits</p>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <div class="single-pie-bar mb-100" data-percent="25">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Studio</p>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-3">
                                <div class="single-pie-bar mb-100" data-percent="69">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Weddings</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- ***** Milestones ***** -->
            <div class="row">
                <div class="col-12">
                    <div class="elements-title">
                        <h2>Milestones</h2>
                    </div>
                </div>

                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100">
                        <img style="width: 3rem" src="img/core-img/golden-ratio.png" alt="">
                        <h2><span class="counter">149</span></h2>
                        <p>Happy Brides</p>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100">
                        <img style="width: 3rem" src="img/core-img/canvas.png" alt="">
                        <h2><span class="counter">2391</span></h2>
                        <p>Landscape Photos</p>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100">
                        <img style="width: 3rem" src="img/core-img/mouse.png" alt="">
                        <h2><span class="counter">245</span></h2>
                        <p>Airbrushed Photos</p>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100">
                        <img style="width: 3rem" src="img/core-img/coffee.png" alt="">
                        <h2><span class="counter">128</span></h2>
                        <p>Coffes a month</p>
                    </div>
                </div>
            </div>

            <!-- ***** Icon Boxes ***** -->
            
    <!-- ***** Elements Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
            <h2>Dream</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | King_Photography  <i class="fa fa-heart-o" aria-hidden="true"></i> 
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>