<?php  
session_start();  
if(!isset($_SESSION["staff"]))
{
 header("location:index.php");
}

ob_start();
?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>King Photography</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link rel="icon" href="assets/img/favicon.png">
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

    <style>
    .imgSec img{
        margin: 10px;
        height:100px;
        width: 100px;
    }
    </style>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">MAIN MENU </a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
			
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="settings.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
					
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    
                    <li>
                        <a class="active-menu" href="uploadimage.php"><i class="fa fa-picture-o"></i>Upload Image</a>
                    </li>
                    <li>
                        <a href="package.php"><i class="fa fa-plus-square"></i>Show Package</a>
                    </li>
                    <li>
                        <a  href="settings.php"><i class="fa fa-dashboard"></i>confirm Date</a>
                    </li>
					<li>
                        <a   href="room.php"><i class="fa fa-plus-circle"></i>Add Date</a>
                    </li>
                    <li>
                        <a  href="roomdel.php"><i class="fa fa-pencil-square-o"></i> Delete Date</a>
                    </li>
					
					

                    
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
       
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           Upload<small> Images </small>
                        </h1>
                    </div>
                </div> 
                 
                                 
            <?php
						include ('db.php');
						$sql = "SELECT * FROM `clogin`";
						$re = mysqli_query($con,$sql)
				?>
                
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>User ID</th>
											<th>User name</th>
                                            <th>order ID</th>
                                            <th>Images</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
									<?php
										while($row = mysqli_fetch_array($re))
										{
										
											$id = $row['cid'];
											$us = $row['username'];
                                            $ps = $row['pass'];
                                            $rid = $row['id'];
                                            
											if($id % 2 ==1 )
											{
												echo"<tr class='gradeC'>
													<td>".$id."</td>
													<td>".$us."</td>
                                                    <td>".$rid."</td>
                                                    
                                                    
                                                 
                                                    <td data-id='". $id ."'>
                                                    <input type='hidden' class='pa' value='$us'>
                                                    <input type='hidden' class='ta' value='$ps'>
                                                    <input type='hidden' class='id' value='$id'>
                                                    <button class='btn btn-primary btn upload' data-toggle='modal' data-target='#myModal'> Upload </button></td>
                                                    </tr>";
											}
											else
											{
												echo"<tr class='gradeU'>
													<td>".$id."</td>
													<td>".$us."</td>
                                                    <td>".$rid."</td>
                                                    
                                                    
                                                    
                                                    <td data-id='". $id ."'>
                                                    <input type='hidden' class='pa' value='$us'>
                                                    <input type='hidden' class='ta' value='$ps'>
                                                    <input type='hidden' class='id' value='$id'>
                                                    <button class='btn btn-primary btn upload' data-toggle='modal' data-target='#myModal'> Upload </button></td>
                                                    </tr>";
											}
										
										}
										
									?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
					

						
					<div class="panel-body">
                            
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Upload Images</h4>
                                        </div>
										<form method="post">
                                            <input type="file" name="" id="file" style="margin:20px">
                                            <input type="hidden" id="cid">
                                        </form>
                                        <div class="imgSec">
                                            <img src="../img/images/1193_1.jpeg" alt="">
                                            <img src="../img/images/1193_1.jpeg" alt="">
                                        </div>
										
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										   
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
               
                <!-- /. ROW  -->
               
                                
                  
            
			 <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-3.4.min.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- <script src="assets/js/morris.min.js"></script> -->

    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();

                $(".update").on('click', function () {
                    const td = $(this).parent('td').attr('id');
                    const us = $('#'+td+' .us').val();
                    const ps = $('#'+td+' .ps').val();
                    const id = $('#'+td+' .id').val();

                    $("#username").val(us);
                    $("#pass").val(ps);
                    $("#cid").val(id);
                });
               
            });

            
    </script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>

    <script>
    // $(document).ready(fucntion(){
             $('.upload').on('click', function(){
                    let id = $(this).closest('td').data('id');
                    $("#cid").val(id);

                    $.ajax({
                        url:'fetchImg.php',
                        method: 'post',
                        data:{
                            cid:id
                        },
                        success:function(data) {
                            const obj = JSON.parse(data);
                            let html = '';
                            for(let i = 0;i < obj.length;i++){
                            console.log(data[i].src);
                                html += '<img src="../images/' + obj[i].src + '">';        
                            }
                            $(".imgSec").html(html);
                        }
                    })

                });   
            $("#file").on('change', function () {

                let cid = $("#cid").val();
                let fd = new FormData();
                let files = $(this).prop('files')[0];
                fd.append('file', files);
                fd.append('cid', cid);
                $.ajax({
                    url: 'attachment.php' ,
                    type: 'post' ,
                    data: fd ,
                    contentType: false ,
                    processData: false ,
                    success:function(data){
                        let html = '<img src="../images/' + data + '">';
                        $(".imgSec").append(html);
                    }

                });
            });
    // })
    </script>
       
</body>
</html>
