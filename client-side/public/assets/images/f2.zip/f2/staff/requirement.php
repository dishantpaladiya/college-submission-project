<?php  
session_start();  
if(!isset($_SESSION["staff"]))
{
 header("location:index.php");
}
?>

<?php
include('db.php');
$rsql ="select id from odetail";
$rre=mysqli_query($con,$rsql);

?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1  .0" />
    <title>King Photography</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- Morris Chart Styles-->
     <link rel="icon" href="assets/img/favicon.png">
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><?php echo $_SESSION["staff"]; ?> </a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="uploadimage.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="home.php"><i class="fa fa-dashboard"></i> Status</a>
                    </li>
                    <li>
                        <a class="active-menu" href="requirement.php"><i class="fa fa-plus-square-o"></i> Requirement</a>
                    </li>
                    <li>
                        <a  href="messages.php"><i class="fa fa-desktop"></i> News Letters</a>
                    </li>
					
                    <li>
                        <a  href="payment.php"><i class="fa fa-qrcode"></i> Payment</a>
                    </li>
                    <li>
                        <a  href="profit.php"><i class="fa fa-long-arrow-up"></i> Profit</a>
                    </li>
                    <li>
                        <a href="logout.php" ><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                    

                    
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
       
        
       
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                        Requirement  <small>Details </small>
                        </h1>
                    </div>
                </div> 
                 
                                 
            <div class="row">
                
                <div class="col-md-12 col-sm-5">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Add Order Details
                        </div>
                        <div class="panel-body">
						<form name="form" method="post">
                        
                        
                        
                        <div class="form-group">
                        <label>Select the ID *</label>
                        <select name="id"  class="form-control" required>
						<option value selected ></option>
					        	<?php
					        	while($rrow=mysqli_fetch_array($rre))
					        	{
					        	$value = $rrow['id'];
					        	echo '<option value="'.$value.'">'.$value.'</option>';						
					        	}
						        ?>
                        </select>
                        </div>




                        <div class="form-group">
                    <label>Detail-A</label>
                    <input type="text" class="form-control" id="det1"  name="det1" >
                    </div>

                    <div class="form-group">
                    <label>Detail-B</label>
                    <input type="text" class="form-control" id="det2"  name="det2" >
                    </div>

                    <div class="form-group">
                    <label>Detail-C</label>
                    <input type="text" class="form-control" id="det3"  name="det3" >
                    </div>

                    <div class="form-group">
                    <label>Detail-D</label>
                    <input type="text" class="form-control" id="det4"  name="det4" >
                    </div>

                    
                
                    <input type="submit" name="add" value="Submit Details" class="btn btn-primary"> 
							

                 </form>
							<?php
							 include('db.php');
							 if(isset($_POST['add']))
							 {
                                        $det1 = $_POST['det1'];
										$det2 = $_POST['det2'];
                                        $det3 = $_POST['det3'];
                                        $det4 = $_POST['det4'];
                                        $id = $_POST['id'];

                                        
										$sql ="INSERT INTO `requirement`( `det1`, `det2`,`det3`,`det4`,`id`) VALUES ('$_POST[det1]','$_POST[det2]','$_POST[det3]','$_POST[det4]','$_POST[id]')" ;
										if(mysqli_query($con,$sql))
										{
										 echo '<script>alert("Requirement Is Update") </script>' ;
										}else {
											echo '<script>alert("Sorry ! Check The System") </script>' ;
                            }
                        }
						
							
							?>
                        </div>
                        
                    </div>
                </div>


                <?php
						include ('db.php');
						$sql = "SELECT * FROM `requirement`";
						$re = mysqli_query($con,$sql)
				?>
                
                
                <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Detail - 1</th>
											<th>Detail - 2</th>
                                            <th>Detail - 3</th>
                                            <th>Detail - 4</th>
                                            <th>Client ID</th>
                                            
											<th>Update</th>
											<th>Remove</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
									<?php 
		 $i=0;
		 while($response= mysqli_fetch_assoc($re) ) { ?>
            <tr>
                
                <td><?php echo $response['det1']; ?></td>
                <td><?php echo $response['det2']; ?></td>
                <td><?php echo $response['det3']; ?></td>
                <td><?php echo $response['det4']; ?></td>
                <td><?php echo $response['id']; ?></td>
               
                
 				
				<td><a class="btn btn-primary btn-sm" class="btn purple btn-sm" href="edit_requirement.php?id=<?php echo $response['id'];?>"><i class="fa fa-edit"></i> EDIT</a>
				
				
                </td>
                <td>
				<a class="btn btn-danger btn-sm delete_button" data-toggle="modal" href="del_requirement.php?id=<?php echo $response['id'];?>">
				<i class="fa fa-times"></i> DELETE </a>
				 </td>
				
            </tr>
		 <?php } ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                  
          
                    
                       
                            
							  
							 
							 
							  
							  
							   
                       </div>
                        
                    </div>
                </div>
                
               
            </div>
                    
            
				
					</div>
			 <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();

                $(".update").on('click', function () {
                    const td = $(this).parent('td').attr('id');
                    const det1 = $('#'+td+' .det1').val();
                    const det2 = $('#'+td+' .det2').val();
                    const det3 = $('#'+td+' .det3').val();
                    const det4 = $('#'+td+' .det4').val();
                    const id = $('#'+td+' .id').val();

                    $("#det1").val(det1);
                    $("#det2").val(det2);
                    $("#det3").val(det3);
                    $("#det4").val(det4);
                    $("#id").val(id);
                })
            });
    </script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>