
    <?php
    include('db.php');

    $first_name = $_POST['first_name'];
    $last_name = $_REQUEST['last_name'];
    $phone_no = $_POST['phone_no'];
    $username = $_REQUEST['username'];
    $password = $_POST['password'];
    $confirm_password = $_REQUEST['confirm_password'];

    session_start();
    unset($_SESSION['error']);
    if ($first_name == '') {
        $_SESSION['error'] = 'First Name is Required.';
        header("Location:register.php");
    } elseif ($last_name == '') {
        $_SESSION['error'] = 'Last Name is Required.';
        header("Location:register.php");
    } elseif ($phone_no == '') {
        $_SESSION['error'] = 'Phone No is Required.';
        header("Location:register.php");
    } elseif ($username == '') {
        $_SESSION['error'] = 'User Name is Required.';
        header("Location:register.php");
    } elseif ($password != $confirm_password) {
        $_SESSION['error'] = 'Password and Confirm Password is not match.';
        header("Location:register.php");
    } else {
        $sql = "INSERT INTO clogin (`first_name`, `last_name`, `phone_no`, `username`, `pass`)
        VALUES ('$first_name', '$last_name', '$phone_no', '$username', '$password');";
        
        if (mysqli_query($con, $sql)) {
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";
        } else {
            echo "ERROR: Hush! Sorry $sql. " . mysqli_error($con);
            die;
        }

        header("Location: login.php");
    }
    ?>