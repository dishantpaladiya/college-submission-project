<html lang="en">
<head>
<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Photography Administrator</title>
    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
</head>
<style>
  .rating {
  display: flex;
  flex-direction: row-reverse;
  float:left;
}

.rating > input{ display:none;}

.rating > label {
  position: relative;
    width: 1em;
    font-size: 6vw;
    color: #FFD600;
    cursor: pointer;
}
.rating > label::before{ 
  content: "\2605";
  position: absolute;
  opacity: 0;
}
.rating > label:hover:before,
.rating > label:hover ~ label:before {
  opacity: 1 !important;
}

.rating > input:checked ~ label:before{
  opacity:1;
}

.rating:hover > input:checked ~ label:before{ opacity: 0.4; }


</style>

<div class="container mt-5"><br><br>
<form action="dagla.php" method="POST">
<div class="row">
<div class="rating">

  <input type="radio" name="rating" value="5" id="5"><label for="5">☆</label>
  <input type="radio" name="rating" value="4" id="4"><label for="4">☆</label>
  <input type="radio" name="rating" value="3" id="3"><label for="3">☆</label>
  <input type="radio" name="rating" value="2" id="2"><label for="2">☆</label>
  <input type="radio" name="rating" value="1" id="1"><label for="1">☆</label>

</div>
</div>
<br><hr>
<div class="row">
  <label>Portfolio Item Description :</label>
  <textarea class="form-control" rows="5" cols="30" id="desc" name="review" required></textarea>
</div> <br>
<input type="submit" value="save" class="btn btn-primary">
<?php
include('db.php');
if($_SERVER['REQUEST_METHOD']=='POST')
{   //variable
  $rating=$_POST['rating'];
  $review=$_POST['review'];

  $sql="INSERT INTO `rating` (`c_name`, `rating`, `review`) VALUES ('v', '$rating', '$review');";
  $result=mysqli_query($conn,$sql);
  if($result)
    {
      echo"<script>
      alert('Thanks for feedback');
      </script>";
    }
}

?>

</form>
