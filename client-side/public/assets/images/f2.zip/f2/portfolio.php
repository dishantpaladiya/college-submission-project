<?php
include('db.php');

$select2 = "SELECT * from package_img";
$query4 = mysqli_query($con,$select2);

include('head.php');

?>

<body>
   
    <?php include('header.php'); ?>
    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/portfolio.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-8">
                        <div class=""></div>
                        <h2>Take a look at our Portfolio</h2>
                        <p>Taking pictures is savoring life intensely, every hundredth of a second.” “Your first 1,000 photographs are your worst.” “The best thing about a picture is that it never changes, even when the people in it do.” “You don't take a photograph, you make it.</p>
                        <!-- <a href="#" class="btn sonar-btn white-btn">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Portfolio Menu -->

    </div>
    <!-- ***** Hero Area End ***** -->

   

    <!-- ****** Gallery Area Start ****** -->
    <section class="sonar-projects-area" id="projects">
        <div class="container-fluid">

        <div class="col-12">
                    <div class="contact-form text-center">

                        <h2>Portfolio</h2>
                        <h5>This page is a selection of some of our favorite work.  If you are interested in learning more about King Photography packages</h5>
                        </div>
                        </div>
                        <br>    
            <div class="row sonar-portfolio">

            

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item landscapes studio wow fadeInUpBig" data-wow-delay="300ms">
                    <a class="gallery-img" href="img/portfolio-img/1.jpg"><img src="img/portfolio-img/1.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                        
                        <p> </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item portraits fashion wow fadeInUpBig" data-wow-delay="500ms">
                    <a class="gallery-img" href="img/portfolio-img/2.jpg"><img src="img/portfolio-img/2.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                        
                        <p>  </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item landscapes studio wow fadeInUpBig" data-wow-delay="700ms">
                    <a class="gallery-img" href="img/portfolio-img/3.jpg"><img src="img/portfolio-img/3.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                       
                        <p> </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item portraits studio wow fadeInUpBig" data-wow-delay="900ms">
                    <a class="gallery-img" href="img/portfolio-img/4.jpg"><img src="img/portfolio-img/4.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                       
                        <p>  </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item landscapes fashion wow fadeInUpBig" data-wow-delay="300ms">
                    <a class="gallery-img" href="img/portfolio-img/5.jpg"><img src="img/portfolio-img/5.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                        
                        <p> </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item portraits fashion wow fadeInUpBig" data-wow-delay="500ms">
                    <a class="gallery-img" href="img/portfolio-img/6.jpg"><img src="img/portfolio-img/6.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                        
                        <p>  </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item landscapes fashion wow fadeInUpBig" data-wow-delay="700ms">
                    <a class="gallery-img" href="img/portfolio-img/7.jpg"><img src="img/portfolio-img/7.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                       
                        <p> </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item portraits studio wow fadeInUpBig" data-wow-delay="900ms">
                    <a class="gallery-img" href="img/portfolio-img/8.jpg"><img src="img/portfolio-img/8.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                        
                        <p>  </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item landscapes studio wow fadeInUpBig" data-wow-delay="300ms">
                    <a class="gallery-img" href="img/portfolio-img/9.jpg"><img src="img/portfolio-img/9.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                       
                        <p> </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item portraits wow fadeInUpBig" data-wow-delay="500ms">
                    <a class="gallery-img" href="img/portfolio-img/10.jpg"><img src="img/portfolio-img/10.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                        
                        <p>  </p>
                    </div>
                </div>

                <!-- Single gallery Item -->
                <div class="col-12 col-sm-6 col-lg-3 single_gallery_item landscapes wow fadeInUpBig" data-wow-delay="700ms">
                    <a class="gallery-img" href="img/portfolio-img/11.jpg"><img src="img/portfolio-img/11.jpg" alt=""></a>
                    <!-- Gallery Content -->
                    <div class="gallery-content">
                     
                        <p> </p>
                    </div>
                </div>

               

         
                        <div class="row">
                        
                        <div class="row">
                        <?php 

                        while($res2 = mysqli_fetch_assoc($query4)) { ?>
                        <div class="col-12 col-sm-6 col-lg-3 single_gallery_item portraits wow fadeInUpBig" >
                        <div class="img_hover  hvr-outline-out">
                        <img src="admin/port_img/<?php echo $res2['image']; ?>" >


                        <div class="img_hover_wrap">
                        <a class="hvr-icon-float-away">
                        </a>
                        </div>
                        </div>
                        </div>

                        <?php } ?>

                        </div><!--row-->
                        </div> <!--container-->


            </div>

            
        </div>
    </section>
    <!-- ****** Gallery Area End ****** -->
 <!-- ***** Call to Action Area Start ***** -->
 <div class="sonar-call-to-action-area bg-gray section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="call-to-action-content">
                        <h2>We are experienced photographers</h2>
                        <!-- <h5>Let’s talk</h5>
                        <a href="#" class="btn sonar-btn mt-100">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Call to Action Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
            <h2>Dream</h2>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | King_Photography  <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>
