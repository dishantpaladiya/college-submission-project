<?php
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>King Photography</title>

    <!-- Favicon  -->
    <link rel="icon" href="http://localhost/f2/img/core-img/favicon.png">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader Start -->
    <div id="preloader">
        <div class="preload-content">
            <div id="sonar-load"></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Grids -->
    <div class="grids d-flex justify-content-between">
        <div class="grid1"></div>
        <div class="grid2"></div>
        <div class="grid3"></div>
        <div class="grid4"></div>
        <div class="grid5"></div>
        <div class="grid6"></div>
        <div class="grid7"></div>
        <div class="grid8"></div>
        <div class="grid9"></div>
    </div>

    <!-- ***** Main Menu Area Start ***** -->
    <div class="mainMenu d-flex align-items-center justify-content-between">
        <!-- Close Icon -->
        <div class="closeIcon">
            <i class="ti-close" aria-hidden="true"></i>
        </div>
        <!-- Logo Area -->
        <div class="logo-area">
            <a href="index.php">King Photography</a>
        </div>
        <!-- Nav -->
        <div class="sonarNav wow fadeInUp" data-wow-delay="1s">
            <nav>
                <ul>
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about-me.php">About Me</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portfolio.php">Portfolio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="elements.php">Elements</a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Copwrite Text -->
        <div class="copywrite-text">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
        </div>
    </div>
    <!-- ***** Main Menu Area End ***** -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="menu-area d-flex justify-content-between">
                        <!-- Logo Area  -->
                        <div class="logo-area">                            
                        <a href="index.php">
                            <img alt="logo" src="img/logo/light-logo.png">
                            </a>
                        </div>

                        <div class="menu-content-area d-flex align-items-center">
                            <!-- Header Social Area -->
                            <div class="header-social-area d-flex align-items-center">
                                <a href="https://in.pinterest.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="https://in.linkedin.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="https://www.Facebook.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://www.Twitter.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="http://localhost/f2/client/sign_up.php" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Registration"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>                            
                                <a href="http://localhost/f2/client/index.php" data-toggle="tooltip" data-placement="bottom" title="Client Login"><i class="fa fa-sign-in" aria-hidden="true"></i></a>
                            </div>
                            <!-- Menu Icon -->
                            <span class="navbar-toggler-icon" id="menuIcon"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Hero Area Start ***** -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide1.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Hemil & Shreya</h2>
                          
                                <p>Great team of photographers by Darshil and team. Very patient and excellent work ethic. We loved all the photos from pre wedding till the reception and very happy with their work.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide2.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Darshil Vastarpara</h2>
                        
                                <p>In photography there is a reality so subtle that it becomes more real than reality.” “There is one thing the photograph must contain, the humanity of the moment.” “Taking an image, freezing a moment, reveals how rich reality truly is.” “Photography is a way of feeling, of touching, of loving.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide3.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Shubham & Princy</h2>
                                
                                <p>Excellent team work!!…lot of creativity and innovative idea that you bring up into our life event. The “Love Portrait” prewedding video was directed into perfection in very less time.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide4.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Chirag & Jinal</h2>
                            
                                <p>Love my wedding and prewedding work amazing experiance.Thanks alot the we choose u. King Photography.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide5.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Keval & Aarshi</h2>
                            
                                <p>Fabulous job! The entire hub of the Taj studio had done the work with utmost care and efficiency .  They capture each and every moment of wedding in such a beautiful manner.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide6.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Alpesh & Daxa</h2>
                                <p>all the way to Ahmedabad I visited here in Surat for my kids photo shoot.. n you guys really rock the pictures I really loved your work..</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide7.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Divya</h2>
                                <p>Had a great time shooting with The King Studio. They dont just click photos, they create memories..</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide8.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Karan & Disha</h2>
                                <p>Best experience that one could have and save it forever is with. Thank you for the best Memories for Life</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide9.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Vijay & Vasuki</h2>
                                <p>King Photography and had great experience with their team. They are one of the best in market, very trustworthy and flexible in all means</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide10.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Maulik Dobariya</h2>
                                <p>Most amazing photographers, very patient, very calm!! They made our day just perfect and their whole service from start to end is so professional. Loved the quality of videos and photos!!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide11.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Jaimin + Bipasha </h2>
                                <p>We had a good experience hiring The King Studio for our wedding. The photos are are really awesome. We shared our ideas of what we want for our wedding and they helped us doing it.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img slide-background-overlay" style="background-image: url(img/bg-img/slide12.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-end">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <div class="line"></div>
                                <h2>Kayra</h2>
                                <p>Excellent team work!!…lot of creativity and innovative idea that you bring up into our life event.The “Love Portrait” prewedding video was directed into perfection in very less time.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Hero Area End ***** -->

    <!-- ***** Portfolio Area Start ***** -->
    <div class="portfolio-area section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="portfolio-title">
                        <h2>“In photography there is a reality so subtle that it becomes more <span>real</span> than <span> reality.</span>”</h2>
                    </div>
                </div>
            </div>

            <div class="row justify-content-between">
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-5">
                    <div class="single-portfolio-item mt-100 portfolio-item-1 wow fadeIn">
                        <div class="backend-content">
                            <img class="dots" src="img/core-img/dots.png" alt="">
                            <h2>Reality</h2>
                        </div>
                        <div class="portfolio-thumb">
                            <img src="img/bg-img/p8.jpg" alt="">
                        </div>
                        <div class="portfolio-meta">
                            <p class="portfolio-date">Dec 12, 2022</p>
                            <h2>Nirav & Mahek</h2>
                        </div>
                    </div>
                </div>
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-6">
                    <div class="single-portfolio-item mt-230 portfolio-item-2 wow fadeIn">
                        <div class="backend-content">
                            <img class="dots" src="img/core-img/dots.png" alt="">
                        </div>
                        <div class="portfolio-thumb">
                            <img src="img/bg-img/p2.png" alt="">
                        </div>
                        <div class="portfolio-meta">
                        <div class="portfolio-thumb">
                            <img src="img/bg-img/p10.jpg" alt="">
                        </div>
                            <p class="portfolio-date">Nov 27, 2022</p>
                            <h2>Jay & Pinal</h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-10">
                    <div class="single-portfolio-item mt-100 portfolio-item-3 wow fadeIn">
                        <div class="backend-content">
                            <img class="dots" src="img/core-img/dots.png" alt="">
                            <h2>Photography</h2>
                        </div>
                        <div class="portfolio-thumb">
                            <img src="" alt="">
                        </div>
                        <div class="portfolio-meta">
                            <!-- <p class="portfolio-date">Dec 21, 2022</p>
                            <h2>Vivek + Dhruvi</h2> -->
                        </div>
                    </div>
                </div>
            </div>

              <div class="row justify-content-end"> 
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-6">
                    <div class="single-portfolio-item portfolio-item-4 wow fadeIn">
                        <div class="backend-content">
                            <img class="dots" src="img/core-img/dots.png" alt="">
                        </div>
                        <!-- <div class="portfolio-thumb"> -->
                            <!-- <img src="img/bg-img/p3-1.jpg" alt=""> -->
                        </div>
                        <div class="portfolio-meta">
                            <!-- <p class="portfolio-date">Nov 29, 2022</p> -->
                            <!-- <h2>Kano Vastarpara</h2> -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-5">
                    <div class="single-portfolio-item portfolio-item-5 wow fadeIn">
                        <div class="backend-content">
                            <img class="dots" src="img/core-img/dots.png" alt="">
                            
                        </div>
                        <div class="portfolio-thumb">
                            <img src="" alt="">
                        </div>
                        <div class="portfolio-meta">
                            <p class="portfolio-date"></p>
                            <h2></h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-4">
                    <div class="single-portfolio-item portfolio-item-6 wow fadeIn">
                        <div class="portfolio-thumb">
                            <img src="img/bg-img/p2.jpg" alt="">
                        </div>
                        <div class="portfolio-meta">
                            <p class="portfolio-date">Oct 12, 2022</p>
                            <h2>Mahir & Jinal</h2>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row justify-content-end">
                <!-- Single Portfoio Area -->
                <div class="col-12 col-md-4">
                    <div class="single-portfolio-item portfolio-item-7 wow fadeIn">
                        <div class="backend-content">
                            <img class="dots" src="img/core-img/dots.png" alt="">
                            <h2></h2>
                        </div>
                        <div class="portfolio-thumb">
                            <img src="img/bg-img/p5.jpg" alt="">
                        </div>
                        <div class="portfolio-meta">
                            <p class="portfolio-date">Sep 02, 2022</p>
                            <h2>Deep & Pinkal</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Portfolio Area End ***** -->

    <!-- ***** Call to Action Area Start ***** -->
    <div class="sonar-call-to-action-area section-padding-0-100">
        <div class="backEnd-content">
            <h2>Dream</h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="call-to-action-content wow fadeInUp" data-wow-delay="0.5s">
                        <h2>I am an experienced photographer</h2>
                        <h5>Let’s talk</h5>
                        <!-- <a href="#" class="btn sonar-btn mt-100">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Call to Action Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>