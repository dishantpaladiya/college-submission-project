<html>

<head>
    <meta charset="UTF-8">
    <title>King Photography CLIENT</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="./client/images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="./client/css/util.css">
    <link rel="stylesheet" type="text/css" href="./client/css/main.css">
    <!--===============================================================================================-->
</head>

<body onload="ClearForm()" style="background-image: url('img/bg-img/slide6.jpg'); display: flex; background-repeat: no-repeat; background-position: center; background-size: cover; justify-content: center; align-items: center;">

    <header class="header-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="menu-area d-flex justify-content-between">
                        <div class="menu-content-area d-flex align-items-center">
                            <!-- Header Social Area -->
                            <div class="header-social-area d-flex align-items-center">
                                
                            </div>
                            <!-- Menu Icon -->
                            <span class="navbar-toggler-icon" id="menuIcon"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="limiter">
        <div style="width: 100%; display: flex; justify-content: center; align-items: center;">
            <div>

                <!-- <form action="insert.php" method="post"> -->

                <fieldset style="border:1px solid black; border-radius: 15px; background-color: #fff; padding: 30px;">
                   
                    <form class="validate-form p-b-33 p-t-5" action="registerinsert.php" method="post">

                    <?php
                        session_start();
                    ?>
                        <span style="margin-left: 10px; color: red;">
                            <?php
                            if (isset($_SESSION['error']) && $_SESSION['error'] != '') {
                                echo $_SESSION['error'];
                            }
                            ?>
                        </span>
                        <div class="register-input validate-input" data-validate="Enter First Name">
                            <input class="input100" type="text" name="first_name" placeholder="First Name" required>
                            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
                        </div>
                        <div class="register-input validate-input" data-validate="Enter Last Name">
                            <input class="input100" type="text" name="last_name" placeholder="Last Name" required>
                            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
                        </div>
                        <div class="register-input validate-input" data-validate="Enter Phone No." >                           
                             <input class="input100" type="text" name="phone_no" placeholder="Phone No." required>
                            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
                        </div>
                        <div class="register-input validate-input" data-validate="Enter User Name">
                            <input class="input100" type="text" name="username" placeholder="User Name" required>
                            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
                        </div>
                        <div class="register-input validate-input" data-validate="Enter Password" >                            
                            <input class="input100" type="text" name="password" placeholder="Password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$" required>
                            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
                        </div>
                        <div class="register-input validate-input" data-validate="Confirm Password" >                            
                            <input class="input100" type="text" name="confirm_password" placeholder="Confirm Password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$" required>
                            <span class="focus-input100" data-placeholder="&#xe82a;"></span>
                        </div>
                        <div class="container-login100-form-btn m-t-32">
                            <input class="login100-form-btn" type="submit" name="submit" value="Create Account" style="margin-right: 20px;">
                            <a href="login.php" class="login100-form-btn">Login </a>
                        </div>

                        <div class="container-login100-form-btn m-t-32">
                            <a href="/f2/index.php" data-toggle="tooltip" data-placement="bottom" title="Go Home" style="color: black; font-size: 30px;"><i class="fa fa-arrow-circle-left"></i></a>
                        </div>

                    </form>
                </fieldset>

                <!-- </form> -->
            </div>

        </div>

    </div>

    <div id="dropDownSelect1"></div>

    <!--===============================================================================================-->
    <script src="./client/vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="./client/vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="./client/vendor/bootstrap/js/popper.js"></script>
    <script src="./client/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="./client/vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="./client/vendor/daterangepicker/moment.min.js"></script>
    <script src="./client/vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="./client/vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="./client/js/main.js"></script>

</body>

</html>


<?php
include('db.php');
?>