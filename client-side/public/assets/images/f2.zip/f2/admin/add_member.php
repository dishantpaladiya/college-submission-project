<?php  
session_start();  
if(!isset($_SESSION["user"]))
{
 header("location:index.php");
}

ob_start();
?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>King Photography</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link rel="icon" href="assets/img/favicon.png">
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">MAIN MENU </a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
			
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="settings.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
					
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="usersetting.php"><i class="fa fa-dashboard"></i>User Dashboard</a>
                    </li>
                    <li>
                        <a href="staffsetting.php"><i class="fa fa-users"></i>Staff Dashboard</a>
                    </li>
                    <li>
                        <a href="clientsetting.php"><i class="fa fa-plus"></i>client Dashboard</a>
                    </li>
                    <li>
                        <a class="active-menu" href="staff_det.php"><i class="fa fa-hand-o-right"></i>Staff Detail</a>
                    </li>
                    <li>
                        <a href="uploadimage.php"><i class="fa fa-picture-o"></i>Upload Image</a>
                    </li>
                    <li>
                        <a href="package.php"><i class="fa fa-plus-square"></i>Add Package</a>
                    </li>
                    <li>
                        <a  href="settings.php"><i class="fa fa-dashboard"></i>confirm Date</a>
                    </li>
					<li>
                        <a   href="room.php"><i class="fa fa-plus-circle"></i>Add Date</a>
                    </li>
                    <li>
                        <a  href="roomdel.php"><i class="fa fa-pencil-square-o"></i> Delete Date</a>
                    </li>
					
					

                    
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
       
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           Member<small> Detail </small>
                        </h1>
                    </div>
                </div> 
                 
                                 
         
                
            <div class="row">
                
                <div class="col-md-10 col-sm-5">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Add Member Details
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                               
                                <form method="POST" action="insert_member.php" onsubmit="return validate()" enctype="multipart/form-data">    

                                <div class="form-group">
						<div class="col-md-2 control-label">
							<label>First Name</label>
						</div>
						<div class="col-md-4">
							<input type="text" placeholder="Enter First name" name="fname" id="album_name" class="form-control" required>
							<p id="p1"></p>
						</div>	
                        </div>	
                       
						<div class="col-md-2">
							<input type="text" placeholder="Middle name" name="mname" id="album_name" class="form-control" required>
							<p id="p1"></p>
						</div>
                        </div>	
                       
						<div class="col-md-4">
							<input type="text" placeholder="Last name" name="lname" id="album_name" class="form-control" required>
							<p id="p1"></p>
						</div>	

                       
						<div class="col-md-2 control-label">
							<label>Phone No:-</label>
						</div>
						<div class="col-md-10">
							<input type="text" placeholder="Phone No" name="phno" id="album_name" class="form-control" required>
							<p id="p1"></p>
					</div>
                    <div class="col-md-2 control-label">
							<label>Address:-</label>
						</div>
						<div class="col-md-10">
							<input type="text" placeholder="Address" name="address" id="album_name" class="form-control" required>
							<p id="p1"></p>
					</div>

                    <div class="col-md-2 control-label">
							<label>Status:-</label>
						</div>
						<div class="col-md-10">
							<input type="text" placeholder="Status" name="status" id="album_name" class="form-control" required>
							<p id="p1"></p>
					</div>

                    <div class="col-md-2 control-label">
							<label>DOB :-</label>
						</div>
						<div class="col-md-4">
							<input type="date" name="dob" id="album_name" class="form-control" required>
							<p id="p1"></p>
					</div>

                    <div class="col-md-2 control-label">
							<label>Gender :-</label>
						</div>
						<div class="col-md-4">
							<input type="text" placeholder="Gender" name="gender" id="album_name" class="form-control" required>
							<p id="p1"></p>
					</div>
                     
                        <div>
				 <div class="col-md-2 control-label">
						  <label>Photo</label>
						 </div>
						 <div class ="col-md-4">
                          <input type="file" id="main_image" name="main_image" required>
						   <p id="p3"></p>
                           </div>
						  
                           <div class="col-md-9 col-md-offset-3">		
			<button type="submit" class="btn btn btn-primary form-control1"> Submit </button>
			</div>
                                    
							</form>		
                                 
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
					
                         <?php 
                            if(isset($_GET['msg']) && isset($_GET['op'])){
                                        if($_GET['msg']==1){
                            echo "<span class='msgp1' 
                                    style='padding:5px 20%; 
                                    color:grey; 
                                    font-size:1.0em; 
                                    margin:0 5% 5px; 
                                    text-shadow: 1px 2px 3px #c8b4b4;
                                    letter-spacing: 1px;
                                    word-spacing: 1px;'>DATA has been ".$_GET['op']." !</span>";
                                }
                                else{
                                    echo "<span class='msgp0' 
                                    style='padding:5px 20%;
                                    color:grey;
                                    font-size:1.0em;
                                    margin:0 5% 5px;
                                    text-shadow: 1px 2px 3px #c8b4b4;
                                    letter-spacing: 1px;
                                    word-spacing: 1px;'>DATA has not ".$_GET['op']." .</span> ";

                                }
                                    }

                                        
                        ?>
                                                


					
              
                                
                  
            
			 <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
                                    

   

      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
