<?php 
require_once('db.php');
/* print_r($_GET);*/
$id = $_GET['id'];
$delete= "DELETE FROM salary WHERE id=".$id;
mysqli_query($con,$delete);
header('Location:salary.php');


?>