<?php

include ('db.php');
$sql = "select * from cimages where cid=".$_POST['cid'];
$re = mysqli_query($con,$sql);


while($row = mysqli_fetch_assoc($re)){
    $res[] = array(
        'src' => $row['src']
    );
}

echo json_encode($res);