<?php
//print_r($_POST);
require_once('db.php');

$username = $_POST['username'];
$pass = $_POST['pass'];

$id = $_POST['id'];

 $update = "UPDATE clogin SET `username`='".$username."',`pass`='".$pass."' WHERE id=".$id; 
mysqli_query($con,$update);
header('Location:clientsetting.php')
?>