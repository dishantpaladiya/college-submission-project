<?php
$con = mysqli_connect("localhost","root","","studio") or die(mysql_error());

?>