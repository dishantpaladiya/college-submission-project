<?php
//print_r($_POST);
require_once('db.php');

$det1 = $_POST['det1'];
$det2 = $_POST['det2'];
$det3 = $_POST['det3'];
$det4 = $_POST['det4'];

$id = $_POST['id'];

 $update = "UPDATE requirement SET `det1`='".$det1."',`det2`='".$det2."',`det3`='".$det3."',`det4`='".$det4."' WHERE id=".$id; 
mysqli_query($con,$update);
header('Location:requirement.php')
?>