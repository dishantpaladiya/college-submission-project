<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("location:index.php");
}
include('db.php');
include('head.php');
?>


<body>
    <div id="wrapper">
        <?php include('header.php'); ?>
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Dashboard
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php
                                 $clientCountSQL = "SELECT * FROM clogin;";
                                 $clientCount = mysqli_query($con, $clientCountSQL);
                                ?>
                                <h4>Total Clients: <?php echo mysqli_num_rows($clientCount); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php
                                 $staffCountSQL = "SELECT * FROM slogin;";
                                 $staffCount = mysqli_query($con, $staffCountSQL);
                                ?>
                                <h4>Total Staffs: <?php echo mysqli_num_rows($staffCount); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php
                                 $orderCountSQL = "SELECT * FROM odetail WHERE stat='complete';";
                                 $orderCount = mysqli_query($con, $orderCountSQL);
                                ?>
                                <h4>Total Confirmed Orders: <?php echo mysqli_num_rows($orderCount); ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            

                <div class="row">
                    <div class="col-md-6">
                        <div class="panel panel-default">
                            <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center;">
                                <div><h4>Clients</h4></div>
                                <!-- <div>
                                    <button>Add Client</button>
                                </div> -->
                            </div>
                            <div class="panel-body">
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-primary">
                                        <div id="collapseTwo" class="panel-collapse in" style="height: auto;">
                                            <div class="panel-body">
                                                <div class="panel panel-default">

                                                    <div class="panel-body">
                                                        <div class="table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>#</th>
                                                                        <th>Full Name</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                <?php
                                                                    $tsql = "select * from clogin";
                                                                    $tre = mysqli_query($con, $tsql);
                                                                    $i = 1;
                                                                    while ($trow = mysqli_fetch_array($tre)) {
                                                                        echo "<tr>
                                                                            <th>" . $i . "</th>
                                                                            <th>" . $trow['username'] . "</th>
                                                                           
                                                                        </tr>";
                                                                        $i++;
                                                                    }
                                                                    ?>

                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End  Basic Table  -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="panel panel-default">
                        <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center;">
                                <div><h4>Staffs</h4></div>
                                <!-- <div>
                                    <button>Add Staff</button> -->
                                <!-- </div> -->
                            </div>
                            <div class="panel-body">
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-primary">
                                        <div id="collapseTwo" class="panel-collapse in" style="height: auto;">
                                            <div class="panel-body">
                                                <div class="panel panel-default">

                                                    <div class="panel-body">
                                                        <div class="table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>#</th>
                                                                        <th>User Name</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>

                                                                    <?php
                                                                    $tsql = "select * from slogin";
                                                                    $tre = mysqli_query($con, $tsql);
                                                                    $i = 1;
                                                                    while ($trow = mysqli_fetch_array($tre)) {
                                                                        echo "<tr>
                                                                            <th>" . $i . "</th>
                                                                            <th>" . $trow['username'] . "</th>
                                                                        </tr>";
                                                                        $i++;
                                                                    }
                                                                    ?>

                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End  Basic Table  -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                </div>
            </div>






            <!-- /. ROW  -->

        </div>
        <!-- /. PAGE INNER  -->
    </div>
    <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>


</body>

</html>