<?php 
require_once('db.php');
/* print_r($_GET);*/
$id = $_GET['id'];
$sid = $_GET['sid'];
$delete= "DELETE FROM view_salary WHERE id=".$id;
mysqli_query($con,$delete);
header('Location:view_salary.php?id='.$sid);


?>