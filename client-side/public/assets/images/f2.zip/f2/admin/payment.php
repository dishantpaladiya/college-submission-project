<?php  
session_start();  
if(!isset($_SESSION["user"]))
{
 header("location:index.php");
}

 ob_start();

?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1  .0" />
    <title>King Photography</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- Morris Chart Styles-->
     <link rel="icon" href="assets/img/favicon.png">
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"><?php echo $_SESSION["user"]; ?> </a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="usersetting.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <a class="active-menu" href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="home.php"><i class="fa fa-dashboard"></i> Status</a>
                    </li>
                    <li>
                        <a href="requirement.php"><i class="fa fa-plus-square-o"></i> Requirement</a>
                    </li>   
                    <li>
                        <a  href="messages.php"><i class="fa fa-desktop"></i> News Letters</a>
                    </li>
					<li>
                        <a href="roombook.php"><i class="fa fa-bar-chart-o"></i> Order Confirmation</a>
                    </li>
                    <li>
                        <a class="active-menu" href="payment.php"><i class="fa fa-qrcode"></i> Payment</a>
                    </li>
                    <li>
                        <a  href="profit.php"><i class="fa fa-long-arrow-up"></i> Profit</a>
                    </li>
                    <li>
                        <a href="logout.php" ><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                    

                    
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                           Payment Details<small> </small>
                        </h1>
                    </div>
                </div> 
                 <!-- /. ROW  -->
				 
				 
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Country</th>
                                            <th>City</th>
                                            <th>Phone No</th>
                                            <th>Function Type</th>
                                            <th>Date</th>
											<th>Status</th>
                                            <th>Total</th>
                                            <th>Amount paid</th>
											<th>Update</th>
                                            <th>Print</th>
                                             </tr>
                                    </thead>
                                    <tbody>
                                        
									<?php
										include ('db.php');
										$sql="select * from odetail";
										$re = mysqli_query($con,$sql);
										while($row = mysqli_fetch_array($re))
										{
										
                                            $id = $row['id'];
                                            $Title = $row['Title'];
											$FName = $row['FName'];
                                            $LName = $row['LName'];
                                            $Email = $row['Email'];
                                            $Country = $row['Country'];
                                            $city = $row['city'];
                                            $Phone = $row['Phone'];
                                            $stype = $row['stype'];
                                            $fdate = $row['fdate'];
                                            $stat = $row['stat'];
                                            $ta = $row['tamount'];
                                            $pa = $row['pamount'];
											
											if($id % 2 ==1 )
											{
                                                echo"<tr class='gradeC'>
                                                <td>".$id."</td>
													<td>".$Title." ".$FName." ".$LName."</td>
													<td>".$Email."</td>
													<td>".$Country."</td>
													<td>".$city."</td>
													<td>".$Phone."</td>
                                                    <td>".$stype."</td>
                                                    <td>".$fdate."</td>
                                                    <td>".$stat."</td>
                                                    <td>".$ta."</td>
                                                    <td>".$pa."</td>
                                                  
                                                    <td id='id_". $id ."'>
                                                    <input type='hidden' class='pa' value='$pa'>
                                                    <input type='hidden' class='ta' value='$ta'>
                                                    <input type='hidden' class='id' value='$id'>
                                                    <button class='btn btn-primary btn update' data-toggle='modal' data-target='#myModal'> Update </button></td>
                                                  <td><a href=print.php?pid=".$id ." <button class='btn btn-primary'> <i class='fa fa-print' ></i> Print</button></td>
													</tr>";
											}
											else
											{
                                                echo"<tr class='gradeU'>
                                                <td>".$id."</td>
													<td>".$Title." ".$FName." ".$LName."</td>
													<td>".$Email."</td>
													<td>".$Country."</td>
													<td>".$city."</td>
													<td>".$Phone."</td>
                                                    <td>".$stype."</td>
                                                    <td>".$fdate."</td>
                                                    <td>".$stat."</td>
                                                    <td>".$ta."</td>
                                                    <td>".$pa."</td>
                                                  

                                                <td id='id_". $id ."'>
                                                    <input type='hidden' class='pa' value='$pa'>
                                                    <input type='hidden' class='ta' value='$ta'>
                                                    <input type='hidden' class='id' value='$id'>
                                                    <button class='btn btn-primary btn update' data-toggle='modal' data-target='#myModal'>
															 Update 
													</button></td>
            
                                                  
                                                <td><a href=print.php?pid=".$id ." <button class='btn btn-primary'> <i class='fa fa-print' ></i> Print</button></td>
											</tr>";
											
											}
										
										}
										
									?>

                                    <div class="panel-body">
                            
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Enter Amount</h4>
                                        </div>
										<form method="post">
                                        <div class="modal-body">
                                            <div class="form-group">
                                            <label>Total Amount</label>
                                            <input name="tamount" value="" id="tamount" class="form-control" placeholder="Enter User name">
                                                <input type="hidden" id="orderId" name="orderId">
											</div>
										</div>
										<div class="modal-body">
                                            <div class="form-group">
                                            <label>Paid Amount</label>
                                            <input name="pamount" value="" id="pamount" class="form-control" placeholder="Enter Password">
											</div>
                                        </div>
										
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											
                                           <input type="submit" name="up" value="Update" class="btn btn-primary">
										  </form>
										   
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->

                <?php 
				if(isset($_POST['up']))
				{
					$tamount = $_POST['tamount'];
					$pamount = $_POST['pamount'];
					$orderId = $_POST['orderId'];

					$upsql = "UPDATE `odetail` SET `tamount`='$tamount',`pamount`='$pamount' WHERE id = '$orderId'";
					if(mysqli_query($con,$upsql))
					{
					echo' <script language="javascript" type="text/javascript"> alert("User name and password update") </script>';
					
				
					}
				
				header("Location: payment.php");
				
                }
                ob_end_flush();
				
				?>

            
                </div>
               
            </div>
        
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();

                $(".update").on('click', function () {
                    const td = $(this).parent('td').attr('id');
                    const ta = $('#'+td+' .ta').val();
                    const pa = $('#'+td+' .pa').val();
                    const id = $('#'+td+' .id').val();

                    $("#tamount").val(ta);
                    $("#pamount").val(pa);
                    $("#orderId").val(id);
                })
            });
    </script>
         <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>
