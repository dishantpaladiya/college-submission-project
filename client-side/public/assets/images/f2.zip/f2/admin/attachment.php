<?php
//print_r($_FILES);
//print_r($_POST);

include ('db.php');
$ran = rand(1000,9999);
$source=$_FILES['file']['tmp_name'];
$destination="../images/".$ran."_".$_FILES['file']['name'];
move_uploaded_file($source,$destination);

$attachment=$ran."_".$_FILES['file']['name'];
if ($_FILES['file']['error']>=1)
{
    echo 1;
} else
{
    $sql = "insert  into cimages values(0,'$attachment','".$_POST['cid']."')";
    $re = mysqli_query($con,$sql);
    echo $attachment;
}

?>