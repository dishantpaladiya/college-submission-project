<?php 
require_once('db.php');

$file_name = $_FILES['filetoupload']['name'];

/*  To seprate file name and extension and store extension in $file_ext_arr (array) */

$file_ext_arr = explode('.',$file_name);

$file_ext = $file_ext_arr[count($file_ext_arr)-1];

/* To save image file name in date format */

$new_file_name = date('YmdHis');

$final_name = $new_file_name. '.' .$file_ext;

$source = $_FILES['filetoupload']['tmp_name'];
$dest = 'port_img/'.$final_name;

move_uploaded_file($source,$dest);
$insert = "INSERT INTO package_img (`image`) VALUES('".$final_name."')";
mysqli_query($con,$insert);
if(mysqli_affected_rows($con) > 0) {
	header('Location:package_img.php?msg=1&op=inserted');
}
	else
	{
	header('Location:package_img.php?msg=0&op=notinserted');
}
?>


