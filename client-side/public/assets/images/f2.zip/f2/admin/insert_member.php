<?php
require_once('db.php');
//echo "<pre>";
//print_r($_POST);
//print_r($_FILES);

$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$phno = $_POST['phno'];
$address = $_POST['address'];
$status = $_POST['status'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$file_name = $_FILES['main_image']['name'];

$file_ext_arr = explode('.',$file_name);

$file_ext = $file_ext_arr[count($file_ext_arr)-1];

/* To save image file name in date format */

$new_file_name = date('YmdHis');

 $final_name = $new_file_name. '.' .$file_ext;

$source = $_FILES['main_image']['tmp_name'];
$dest = 'upload/'.$final_name;

move_uploaded_file($source,$dest);
 $insert = "INSERT INTO add_mem (`fname`,`mname`,`lname`,`phno`,`address`,`status`,`dob`,`gender`,`image`) VALUES('".					$fname."','".$mname."','".$lname."','".$phno."','".$address."','".$status."','".$dob."','".								$gender."','".$final_name."')";  
mysqli_query($con,$insert);

if(mysqli_affected_rows($con) > 0) {
	header('Location:staff_det.php?msg=1&op=inserted');
}
	else
	{
	header('Location:staff_det.php?msg=0&op=notinserted');
}
?>

