<?php
//print_r($_POST);
require_once('db.php');

$fname = $_POST['fname'];
$mname = $_POST['mname'];
$lname = $_POST['lname'];
$phno = $_POST['phno'];
$address = $_POST['address'];
$status = $_POST['status'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];

$id = $_POST['id'];

 $update = "UPDATE add_mem SET `fname`='".$fname."',`mname`='".$mname."',`lname`='".$lname."',`phno`='".$phno."',`address`='".$address."',`status`='".$status."',`dob`='".$dob."',`gender`='".$gender."'WHERE id=".$id; 
mysqli_query($con,$update);
header('Location:staff_det.php')
?>