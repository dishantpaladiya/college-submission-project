
<?php

session_start();  
if(!isset($_SESSION["user"]))
{
 header("location:index.php");
}
include('db.php');
$id = $_GET['id'];
$select = "SELECT * FROM clogin WHERE id=".$id;

$query = mysqli_query($con,$select);
 ($response = mysqli_fetch_assoc($query));

?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>King Photography</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link rel="icon" href="assets/img/favicon.png">
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php">MAIN MENU </a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
			
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="settings.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
					
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="usersetting.php"><i class="fa fa-dashboard"></i>User Dashboard</a>
                    </li>
                    <li>
                        <a href="staffsetting.php"><i class="fa fa-users"></i>Staff Dashboard</a>
                    </li>
                    <li>
                        <a class="active-menu" href="clientsetting.php"><i class="fa fa-plus"></i>client Dashboard</a>
                    </li>
                    <li>
                        <a href="staff_det.php"><i class="fa fa-hand-o-right"></i>Staff Detail</a>
                    </li>
                    <li>
                        <a href="salary.php"><i class="fa fa-inr"></i>Staff Salary</a>
                    </li> 
                    <li>
                        <a href="Package_img.php"><i class="fa fa-star"></i>Portfolio Image</a>
                    </li>
                    <li>
                        <a href="uploadimage.php"><i class="fa fa-picture-o"></i>Upload Image</a>
                    </li>
                    <li>
                        <a href="package.php"><i class="fa fa-plus-square"></i>Add Package</a>
                    </li>
                    <li>
                        <a  href="settings.php"><i class="fa fa-dashboard"></i>confirm Date</a>
                    </li>
					<li>
                        <a   href="room.php"><i class="fa fa-plus-circle"></i>Add Date</a>
                    </li>
                    <li>
                        <a  href="roomdel.php"><i class="fa fa-pencil-square-o"></i> Delete Date</a>
                    </li>
					
					

                    
            </div>

        </nav>
        <!-- /. NAV SIDE  -->
       
        
       
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                        Requirement  <small>Details </small>
                        </h1>
                    </div>
                </div> 
                 
                                 
            <div class="row">
                
                <div class="col-md-6 col-sm-5">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Add Order Details
                        </div>
                        <div class="panel-body">
                        <form method="POST" action="update_client_setting.php" onsubmit="validate()" enctype="multipart/form-data">
                        
                      
                    <div class="form-group">
	<label>username </label><br>
<input type="text" value="<?php echo $response['username'];?>" name="username" id="album_name" class="form-control"> </div>	 

<div class="form-group">
	<label>Password </label><br>
<input type="text" value="<?php echo $response['pass'];?>" name="pass" id="album_name" class="form-control"> </div>	 


 

                    
<input type="hidden" name="id" value="<?php echo $response['id'];?>">			
			<button type="submit" class="btn btn btn-primary form-control"> Submit </button>

                
							

                 </form>
							
                 
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                  
          
                    
                       
                            
							  
							 
							 
							  
							  
							   
                       </div>
                        
                    </div>
                </div>
                
               
            </div>
                    
            
				
					</div>
			 <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- DATA TABLE SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();

                $(".update").on('click', function () {
                    const td = $(this).parent('td').attr('id');
                    const det1 = $('#'+td+' .det1').val();
                    const det2 = $('#'+td+' .det2').val();
                    const det3 = $('#'+td+' .det3').val();
                    const det4 = $('#'+td+' .det4').val();
                    const id = $('#'+td+' .id').val();

                    $("#det1").val(det1);
                    $("#det2").val(det2);
                    $("#det3").val(det3);
                    $("#det4").val(det4);
                    $("#id").val(id);
                })
            });
    </script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    
   
</body>
</html>