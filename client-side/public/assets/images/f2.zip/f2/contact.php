<?php
include('db.php');
include('head.php');
?>

<body>
   
    <?php include('header.php'); ?>
    
    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
       
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/contact.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-8">
                        <div class=""></div>
                        <h2>Contact Us</h2>
                        <p>We want to hear from you!<br>If you have any questions about the site or need support, please fill out the form below, and we will respond to your request as quickly as possible.
                    </p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Hero Area End ***** -->

    <section class="sonar-contact-area section-padding-100">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
        </div>
        
        <div class="container">
            <div class="row">
                <!-- Contact Form Area -->
                <div class="col-12">
                    <div class="contact-form text-center">

                        <h2>We are experienced photographers</h2>
                        <!-- <h4>Let’s talk</h4> -->

                        <form name="sentMessage" method="post">
                            <div class="row">
                                <!-- <div class="col-12 col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="name" placeholder="Your Name" name="name" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-12 col-md-4">
                                    <div class="form-group">
                                        <input type="email" class="form-control email" id="email" placeholder="Your Email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-12 col-md-4">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="subject" placeholder="Subject" name= "subject">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea class="form-control" name="message" id="message" cols="30" rows="10" placeholder="Message" name="message"></textarea>
                                    </div>
                                </div> -->
                                <div class="col-12">
                                    <a>
                                        <a href="mailto:kingphotography@gmail.com" type="submit" name="sub" class="btn sonar-btn">Contact Us</a>
                                    </a>
                                </div>
                            </div>
                        </form>

                        <?php
				                if(isset($_POST['sub']))
				            {
					            $name =$_POST['name'];
                                $email = $_POST['email'];
                                $subject = $_POST['subject'];
                                $message = $_POST['message'];
					            $approval = "Not Allowed";
					            $sql = "INSERT INTO contact(name, email, subject,message,approval) VALUES ('$name','$email','$subject','$message','$approval')" ;
					
					
					            if(mysqli_query($con,$sql))
					            echo" ";
					
				            }
				        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
            <h2>Dream</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwuyLRa1uKNtbgx6xAJVmWy-zADgegA2s"></script>
    <script src="js/map-active.js"></script>

</body>

</html>
