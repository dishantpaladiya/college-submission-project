<?php
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>King Photography</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.png">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader Start -->
    <div id="preloader">
        <div class="preload-content">
            <div id="sonar-load"></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- Grids -->
    <div class="grids d-flex justify-content-between">
        <div class="grid1"></div>
        <div class="grid2"></div>
        <div class="grid3"></div>
        <div class="grid4"></div>
        <div class="grid5"></div>
        <div class="grid6"></div>
        <div class="grid7"></div>
        <div class="grid8"></div>
        <div class="grid9"></div>
    </div>

    <!-- ***** Main Menu Area Start ***** -->
    <div class="mainMenu d-flex align-items-center justify-content-between">
        <!-- Close Icon -->
        <div class="closeIcon">
            <i class="ti-close" aria-hidden="true"></i>
        </div>
        <!-- Logo Area -->
        <div class="logo-area">
            <a href="index.php">King Photography</a>
        </div>
        <!-- Nav -->
        <div class="sonarNav">
            <nav>
                <ul>
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about-me.php">About Me</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portfolio.php">Portfolio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Elements</a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Copwrite Text -->
        <div class="copywrite-text">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
        </div>
    </div>
    <!-- ***** Main Menu Area End ***** -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="menu-area d-flex justify-content-between">
                        <!-- Logo Area  -->
                        <div class="logo-area">
                            <a href="index.php">
                                <img src="img/logo/light-logo.png" alt="logo">
                            </a>
                        </div>

                        <div class="menu-content-area d-flex align-items-center">
                            <!-- Header Social Area -->
                            <div class="header-social-area d-flex align-items-center">
                                <a href="https://in.pinterest.com" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="https://in.linkedin.com"  data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com" data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="https://www.Facebook.com" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://www.Twitter.com" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="http://localhost/f2/client/sign_up.php" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Registration"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
                                <a href="/f2/client/" data-toggle="tooltip" data-placement="bottom" title="Client Login"><i class="fa fa-sign-in" aria-hidden="true"></i></a>
                            </div>
                            <!-- Menu Icon -->
                            <span class="navbar-toggler-icon" id="menuIcon"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/services.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-8">
                        <div class=""></div>
                        <h2>We provide top quality services</h2>
                        <p>A professional wedding photographer is a kind of magician. Thanks photography we can catch and save the most important moments or emotions in our life. You can switch on your imagination and choose a candid photography. Wedding shoot is also for your services. We provide you with a high qualified specialist, a person you can rely on and thrust.</p>
                        <!-- <a href="contact.php" class="btn sonar-btn white-btn">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Hero Area End ***** -->

    <!-- ***** Services Area Start ***** -->
    <div class="sonar-services-area section-padding-100-50">
        <div class="container">
            <div class="row">
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="300ms">
                        <img src="img/core-img/camera.jpg" alt="dd" style= "width: 15rem,height: auto";>
                        <h4>Wedding Photograpy</h4>
                        <p>Your wedding is a special milestone in your life and in the life of those around you. Why not make it even more exciting by getting some of the best wedding photographers in India to capture these magical moments.</p>
                        
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="600ms">
                        <img src="img/core-img/vector.png" alt="">
                        <h4>Pre-Wedding photography</h4>
                        <p>Pre-Wedding Shoots offered by us is one of the most fun oriented and emotionally enriching experience for both the newly weds or to-be-weds. Involving a casual - non formal location with stunning results.
                        </p>
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="900ms">
                        <img src="img/core-img/pantone.png" alt="">
                        <h4>Engagement photography</h4>
                        <p>Engagement is one of the most precious moments in everyone’s life. All of us would like to celebrate this beautiful priceless moment in different ways. Why not make it even more exiting with best photographers.</p>
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="300ms">
                        <img src="img/core-img/video-player.png" alt="">
                        <h4>Baby Shower photography</h4>
                        <p>It’s tradition for most baby bashes to be thrown towards the end of a pregnancy, Mom and her little bundle are going to be surrounded by a whole lot of love and inspirational words after her baby shower. Its good to capture a moment with best photographer.
                        </p>
                    
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="600ms">
                        <img src="img/core-img/browsing.png" alt="">
                        <h4>Event photography</h4>
                        <p>Grow your business with capture your event, Why not make it even more exciting by getting some of the best photographers in India to capture these moments.
                        </p>
                      
                    </div>
                </div>
                <!-- Single Services Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-services-area wow fadeInUp" data-wow-delay="900ms">
                        <img src="img/core-img/develop.jpg" alt="">
                        <h4>Portrait photography</h4>
                        <p>Grow your talent with capture your best high quality photos and videos with best poses, its very helpful to meet a best photographers, Why not make it even more exciting by getting some of the best photographers in India to capture these moments.
                        </P>
                  
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Services Area End ***** -->

    <div class="sonar-testimonials-area bg-img" style="background-image: url(img/bg-img/tes.jpg);">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-10 col-lg-7">
                    <div class="testimonial-content bg-white">
                        <div class="section-heading text-left">
                            <div class=""></div>
                            <h2>Reviews</h2>
                        </div>

                        <div class="testimonial-slides owl-carousel">

                            <div class="single-tes-slide">
                                <p>This company is so easy to use and make payments up till my wedding date it took so much stress off of me! being able to view all the photographers in the area's profiles was so simple and they reached out to me to go over everything that I wanted for our wedding! I literally got my photos back a week and a half later and couldn't be more pleased! thank you for making this such a stress free process now I get to enjoy my photos forever and my photographer was phenomenal.. search really went above and beyond with an outdoor venue and rain on the same day she made it work and got amazing photos for us to forever enjoy. 💜</p>
                                <h6>Drashti C, Bride</h6>
                            </div>

                            <div class="single-tes-slide">
                                <p>Amazing Amazing Amazing!! I needed a wedding photographer in 3 days and Classic Photography made it happen. Such an amazing crew to work with they made sure they took pictures of everything we wanted them too. I would highly recommend them!!</p>
                                <h6>Aastha W, Baby Shower</h6>
                            </div>

                            <div class="single-tes-slide">
                                <p>Amazing service and the monthly payment plan is very ideal for couples from a saving perspective!.</p>
                                <h6>Raquel R.</h6>
                            </div>

                            <div class="single-tes-slide">
                                <p>We had a wonderful experience with our photographers, Aly and Kylie, plus our videographer TJ! We got our photos back in 6 days! AMAZING. Everyone was so professional, the photos are absolutely stunning. Loved the flexibility of customized packages through Classic and being able to bundle photography + videography was so convenient.</p>
                                <h6>Lauren L.</h6>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="cool-facts-area section-padding-100-0">
        <div class="container">
            <div class="row align-items-center">
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100 wow fadeInUpBig" data-wow-delay="250ms">
                        <img src="img/core-img/golden-ratio.jpg" alt="">
                        <h2><span class="counter">149</span></h2>
                        <h4>Happy Brides</h4>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100 wow fadeInUpBig" data-wow-delay="500ms">
                        <img src="img/core-img/canvas.jpg" alt="">
                        <h2><span class="counter">2391</span></h2>
                        <h4>Landscape Photos</h4>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100 wow fadeInUpBig" data-wow-delay="750ms">
                        <img src="img/core-img/mouse.png" alt="">
                        <h2><span class="counter">245</span></h2>
                        <h4>Airbrushed Photos</h4>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-cool-fact-area text-center mb-100 wow fadeInUpBig" data-wow-delay="1000ms">
                        <img src="img/core-img/coffee.jpg" alt="">
                        <h2><span class="counter">128</span></h2>
                        <h4>Coffes a month</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ***** Call to Action Area Start ***** -->
    <div class="sonar-call-to-action-area bg-gray section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="call-to-action-content">
                        <h2>I am an experienced photographer</h2>
                        <h5>Let’s talk</h5>
                        <!-- <a href="contact.php" class="btn sonar-btn mt-100">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Call to Action Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area bg-gray">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
            <h2>Dream</h2>
        </div>
        
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>