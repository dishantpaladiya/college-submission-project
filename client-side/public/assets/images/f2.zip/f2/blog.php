<?php
include('db.php');
include('head.php');
?>

<body>
   
    <?php include('header.php'); ?>
    
    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
       
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/blo.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-8">
                        <div class=""></div>
                        <h2>Just a Photography blog</h2>
                        <p></p>
                        <!-- <a href="contact.php" class="btn sonar-btn white-btn">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Hero Area End ***** -->

    <!-- ***** Blog Area Start ***** -->
    <section class="sonar-blog-area section-padding-100">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12 col-md-9">

                    <!-- Single Blog Area -->
                    <div class="single-blog-area mb-100 wow fadeInUp" data-wow-delay="300ms">
                        <!-- Post Thumbnail -->
                        <div class="blog-post-thumbnail">
                            <img src="img/blog-img/1.jpg" alt="">
                            <!-- Post Date -->
                            <div class="post-date">
                                <a href="#">Feb 12 '21</a>
                            </div>
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <a href="#" class="headline">S + G an elegant affair</a>
                            <div class="post-meta">
                                <a href="#" class="comments">By Drashti Shiroya</a> | <a href="#" class="comments">2 Comments</a>
                            </div>
                            <p>The Indain Brides Want To Select The Best Candid Photographer Who Gives Them The Best Candid Photography With Great Ideas And Different Concepts Not Only In Shoots But Also In Albums , She Has Become a Lot More Aware , She Also Loves Flaunting The Pi...</p>
                        </div>
                    </div>

                    <!-- Single Blog Area -->
                    <div class="single-blog-area mb-100 wow fadeInUp" data-wow-delay="600ms">
                        <!-- Post Thumbnail -->
                        <div class="blog-post-thumbnail">
                            <img src="img/blog-img/2.jpg" alt="">
                            <!-- Post Date -->
                            <div class="post-date">
                                <a href="#">Feb 12 '21</a>
                            </div>
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <a href="#" class="headline">India`s Best Destination Wedding Photographer at Nepal from Delhi</a>
                            <div class="post-meta">
                                <a href="#" class="comments">By Pinkal dobariya</a> | <a href="#" class="comments">2 Comments</a>
                            </div>
                            <p>The flavour of an indian wedding really outshines , when its a destination wedding , and it becomes even more intresting when it is starred by extremely fun loving bindaas people, this ones is exactly that , starring loads of fun moments , ...</p>
                        </div>
                    </div>

                    <!-- Single Blog Area -->
                    <div class="single-blog-area mb-100 wow fadeInUp" data-wow-delay="900ms">
                        <!-- Post Thumbnail -->
                        <div class="blog-post-thumbnail">
                            <img src="img/blog-img/3.jpg" alt="">
                            <!-- Post Date -->
                            <div class="post-date">
                                <a href="#">Feb 12 '21</a>
                            </div>
                        </div>
                        <!-- Post Content -->
                        <div class="post-content">
                            <a href="#" class="headline">Babies and Photography</a>
                            <div class="post-meta">
                                <a href="#" class="comments">By Dharmi kakadiya</a> | <a href="#" class="comments">2 Comments</a>
                            </div>
                            <p>The indain brides want to select the best candid photographer who gives them the best candid photography with great ideas and different concepts not only in shoots but also in albums , she has become a lot more aware , she also loves flaunting the pi...</p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-3">
                    <div class="sonar-blog-sidebar-area">

                        <!-- Search Widget -->
                        <div class="search-widget-area mb-50">
                            <form action="#" method="get">
                                <input type="search" placeholder="Search">
                                <button type="submit"><i class="ti-search"></i></button>
                            </form>
                        </div>

                        <!-- Archive Widget -->
                        <div class="sonar-catagories-widget-area mb-50">
                            <h6>Archive</h6>
                            <ul class="catagories-menu">
                                <li><a href="#">March 2022</a></li>
                                <li><a href="#">April 2022</a></li>
                                <li><a href="#">May 2022</a></li>
                                <li><a href="#">June 2022</a></li>
                            </ul>
                        </div>

                        <!-- Catagories Widget -->
                        <div class="sonar-catagories-widget-area mb-50">
                            <h6>Categories</h6>
                            <ul class="catagories-menu">
                                <li><a href="#">Uncategorized</a></li>
                                <li><a href="#">Usefull Information</a></li>
                                <li><a href="#">Events</a></li>
                                <li><a href="#">Business</a></li>
                                <li><a href="#">Marketing</a></li>
                                <li><a href="#">Conference &amp; Press</a></li>
                            </ul>
                        </div>

                       
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            
        </div>
    </section>
    <!-- ***** Blog Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
            <h2>Dream</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>