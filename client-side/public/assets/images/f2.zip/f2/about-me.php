<?php
include('db.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>King Photography</title>

    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.png">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader Start -->
    <div id="preloader">
        <div class="preload-content">
            <div id="sonar-load"></div>
        </div>
    </div>
    <!-- Preloader End -->

    <!-- ***** Main Menu Area Start ***** -->
    <div class="mainMenu d-flex align-items-center justify-content-between">
        <!-- Close Icon -->
        <div class="closeIcon">
            <i class="ti-close" aria-hidden="true"></i>
        </div>
        <!-- Logo Area -->
        <div class="logo-area">
            <a href="index.php">King Photography</a>
        </div>
        <!-- Nav -->
        <div class="sonarNav">
            <nav>
                <ul>
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about-me.php">About Me</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="portfolio.php">Portfolio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blog.php">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Elements</a>
                    </li>
                </ul>
            </nav>
        </div>
        <!-- Copwrite Text -->
        <div class="copywrite-text">
            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
        </div>
    </div>
    <!-- ***** Main Menu Area End ***** -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="menu-area d-flex justify-content-between">
                        <!-- Logo Area  -->
                        <div class="logo-area">
                        <a href="index.php">
                            <img alt="logo" src="img/logo/light-logo.png">
                            </a>
                        </div>

                        <div class="menu-content-area d-flex align-items-center">
                            <!-- Header Social Area -->
                            <div class="header-social-area d-flex align-items-center">
                                <a href="https://in.pinterest.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="https://in.linkedin.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="https://www.Facebook.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="https://www.Twitter.com" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="http://localhost/f2/client/sign_up.php" target="_blank" data-toggle="tooltip" data-placement="bottom" title="Registration"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
                                <a href="/f2/client/" data-toggle="tooltip" data-placement="bottom" title="Client Login"><i class="fa fa-sign-in" aria-hidden="true"></i></a>
                            </div>
                            <!-- Menu Icon -->
                            <span class="navbar-toggler-icon" id="menuIcon"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
        <!-- Back End Content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
        </div>

        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail aboutUs equalize bg-img" style="background-image: url(img/bg-img/about.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content aboutUs equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-10">
                    
                        <h2> Let's Capture The Moment</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt quisquam eaque perspiciatis culpa cum qui voluptatibus? Provident nostrum ut quod quidem quos expedita, rerum blanditiis qui itaque hic facilis fugit optio perspiciatis at laudantium beatae ipsa aspernatur praesentium quaerat magnam recusandae vero id voluptates corporis! Sequi dolore blanditiis expedita vel animi quaerat incidunt consequuntur laborum. Temporibus unde, minus optio quidem consectetur rerum sed, esse voluptatem amet nihil perferendis iste numquam. Quos provident doloremque ex aliquid voluptas asperiores earum illum iure perferendis explicabo blanditiis voluptates, est harum ut molestias? Nemo dolorem ipsum fugit dolores, eos illo? Eveniet nostrum numquam temporibus amet!.</p>
                        <!-- <a href="contact.php" class="btn sonar-btn white-btn">contact me</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Hero Area End ***** -->

    <div class="sonar-about-us-area bg-img" >
       
        <!-- Back End Content -->
        <div class="backEnd-content">
            <h2>Dream</h2>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-10 col-lg-7">
                    <div class="about-us-content bg-white">
                        <div class="section-heading text-left wow fadeInUp" data-wow-delay="300ms">
                            <div class=""></div>
                            <h2>Look at my Qualities</h2>
                        </div>
                      
                        <p class="wow fadeInUp" data-wow-delay="600ms">“Finding a photographer was one of the most important decisions we had to make for our wedding, and we could not have chosen a better one! Jenish and his assistants were amazing to work with and the photos that followed, just as amazing. We have had compliments galore about our pictures and I credit that all to Jenish. Words can barely describe how happy we are with our shots and our decision to go with MMP. You will NOT be disappointed!”</p>
                        <!-- Progress Bar Content Area -->
                        <div class="services-progress-bar mt-50 wow fadeInUp" data-wow-delay="900ms">
                            <!-- Single Progress Bar -->
                            <div class="single_progress_bar">
                                <div id="bar1" class="barfiller">
                                    <div class="tipWrap">
                                        <span class="tip"></span>
                                    </div>
                                    <span class="fill" data-percentage="80"></span>
                                </div>
                                <p>Pacience</p>
                            </div>
                            <!-- Single Progress Bar -->
                            <div class="single_progress_bar">
                                <div id="bar2" class="barfiller">
                                    <div class="tipWrap">
                                        <span class="tip"></span>
                                    </div>
                                    <span class="fill" data-percentage="90"></span>
                                </div>
                                <p>Creativity</p>
                            </div>
                            <!-- Single Progress Bar -->
                            <div class="single_progress_bar">
                                <div id="bar3" class="barfiller">
                                    <div class="tipWrap">
                                        <span class="tip"></span>
                                    </div>
                                    <span class="fill" data-percentage="100"></span>
                                </div>
                                <p>Commited</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-10 col-lg-5">
                    <img src="img/bg-img/about2.jpg" class="bg" alt="vvfsdgdfsd" height="100%" width="100%">
</div>
            </div>
        </div>
    </div>

    
        <!-- Back End Content -->
        <div class="sonar-about-us-area bg-img" >
       
        <!-- Back End Content -->
        <div class="backEnd-content">
            <h2>Really</h2>
        </div>

        <div class="container-fluid">
            <div class="row justify-content-end">
            <div class="col-12 col-md-10 col-lg-5">
        <img src="img/bg-img/about3.jpg" class="bb" alt="aaa" height="100%" width="100%">
</div>
                <div class="col-12 col-md-10 col-lg-7">
                    <div class="about-us-content bg-white">
                        <div class="section-heading text-left wow fadeInUp" data-wow-delay="300ms">
                            
                        </div>
                        <p class="wow fadeInUp" data-wow-delay="600ms">.</p>
                        <div class="row mt-100 text-center wow fadeInUp" data-wow-delay="900ms">
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="single-pie-bar" data-percent="90">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Landsacpes</p>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="single-pie-bar" data-percent="65">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Portraits</p>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="single-pie-bar" data-percent="25">
                                    <canvas class="bar-circle" width="100" height="100"></canvas>
                                    <p>Studio</p>
                                    <div class="col-12 col-sm-6 col-md-4">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12 mt-5">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>All rights reserved | King_Photography <i class="fa fa-heart-o" aria-hidden="true"></i>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>